Complete Details
About Nordstrom-Project ---  https://hashnode.com/post/nordstrom-website-clone-ckvxz38t9049mz2s1cc7zgota
#h1 Nordstrom website clone
Good day, everyone! I hope you're all doing well. I'm making this blog to tell you about my entire team's experience of cloning (this website) during our first construct week. We got a total of 15 days to complete this job.

What is construct week and what is its purpose? Construct week is an element of Masai School's curriculum that allows us to explore and apply all of the topics we've learned in class. By putting all of our skills to work on a project, we learn a lot about how things actually work and how to apply our knowledge to effective use. The primary objective of this activity is to acquire these front-end skills by creating replicas of these websites as identical as possible.


Practising does not make you perfect, but it does bring you closer to being perfect.
We are team Nordstrom and in our team, there are 6 members including me.

Sumit Mishra
Keshav Kumar Mishra
Shivanshu Mishra
Malaya Kumar Biswal
Vivek Sharma
Tools we used
Slack (for text communication)
Zoom (for meetings)
VS code (for the project)
Github (for version control)
Technologies we used
HTML
CSS
Javascript
Nordstrom.com Nordstrom, Inc. is an American luxury department store chain. Where users can buy everything from clothes to shoes.
